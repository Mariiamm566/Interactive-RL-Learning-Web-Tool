import asyncio
import json
import os
from aiohttp import web, WSMsgType

from environments import list_envs, create_env
from algorithms import list_algorithms, PolicyIter, ValueIter, PolicyEval, MC, TD0, NStepTD, SARSA, QLearn, policy_overlay

AGENTS = {
    "PolicyIter": PolicyIter,
    "ValueIter": ValueIter,
    "PolicyEval": PolicyEval,
    "MC": MC,
    "TD0": TD0,
    "NStepTD": NStepTD,
    "SARSA": SARSA,
    "QLearn": QLearn,
}

def _is_dp(algo_key: str) -> bool:
    return algo_key in ("PolicyIter", "ValueIter")

async def index(request):
    return web.FileResponse(os.path.join(request.app["web_dir"], "index.html"))

async def ws(request):
    sock = web.WebSocketResponse(heartbeat=25)
    await sock.prepare(request)

    cfg = {
        "env": "GridWorld",
        "algo": "TD0",
        "gamma": 0.99,
        "alpha": 0.20,
        "epsilon": 0.15,
        "eps_decay": 0.9995,
        "n_step": 5,
        "batch": 2,
        "max_steps": 200,
        "shaping": 0.0,
        "seed": 0,
    }

    env = create_env(cfg["env"], shaping=cfg["shaping"], seed=cfg["seed"])
    agent = AGENTS[cfg["algo"]](env, gamma=cfg["gamma"], alpha=cfg["alpha"], epsilon=cfg["epsilon"], n_step=cfg["n_step"], eps_decay=cfg["eps_decay"])

    running = False
    task = None

    async def send(obj):
        if not sock.closed:
            await sock.send_str(json.dumps(obj))

    async def rebuild():
        nonlocal env, agent
        env = create_env(cfg["env"], shaping=cfg["shaping"], seed=cfg["seed"])
        akey = cfg["algo"]
        if _is_dp(akey) and not env.has_model():
            cfg["algo"] = "TD0"
            akey = "TD0"
        cls = AGENTS[akey]
        agent = cls(env, gamma=cfg["gamma"], alpha=cfg["alpha"], epsilon=cfg["epsilon"], n_step=cfg["n_step"], eps_decay=cfg["eps_decay"])

    async def emit_tick(metrics=None, viz=None):
        metrics = metrics or {}
        viz = viz or {}
        viz["frame"] = env.frame()
        if "policy" not in viz and hasattr(agent, "pi"):
            viz["policy"] = policy_overlay(getattr(agent, "pi"), env)
        payload = {
            "type": "tick",
            "metrics": metrics,
            "viz": viz,
            "env": {"key": env.key, "snap": env.snapshot()},
        }
        await send(payload)

    async def warm():
        viz = {"frame": env.frame()}
        if hasattr(agent, "V"):
            viz["V"] = getattr(agent, "V").tolist()
        if hasattr(agent, "Q"):
            q = getattr(agent, "Q")
            viz["Qmax"] = (q.max(axis=1)).tolist()
        if hasattr(agent, "pi"):
            viz["policy"] = policy_overlay(getattr(agent, "pi"), env)
        await emit_tick(metrics={"status": "ready"}, viz=viz)

    async def loop():
        nonlocal running
        while running and not sock.closed:
            try:
                agent.tune(gamma=cfg["gamma"], alpha=cfg["alpha"], epsilon=cfg["epsilon"], n_step=cfg["n_step"], eps_decay=cfg["eps_decay"])
                env.set_shaping(cfg["shaping"])
                out = agent.learn(batches=cfg["batch"], max_steps=cfg["max_steps"])
                await emit_tick(metrics=out.get("metrics", {}), viz=out.get("viz", {}))
            except Exception as e:
                await emit_tick(metrics={"error": str(e)}, viz={})
                running = False
                break
            await asyncio.sleep(0.02)

    await send({"type":"spec", "envs": list_envs(), "algos": list_algorithms()})
    await send({"type":"cfg", "cfg": cfg})
    await warm()

    async for msg in sock:
        if msg.type != WSMsgType.TEXT:
            continue
        try:
            data = json.loads(msg.data)
        except Exception:
            continue

        mtype = data.get("type","")
        if mtype == "cfg":
            patch = data.get("patch", {})
            for k, v in patch.items():
                if k in cfg:
                    cfg[k] = v
            cfg["gamma"] = float(cfg["gamma"])
            cfg["alpha"] = float(cfg["alpha"])
            cfg["epsilon"] = float(cfg["epsilon"])
            cfg["eps_decay"] = float(cfg["eps_decay"])
            cfg["n_step"] = int(cfg["n_step"])
            cfg["batch"] = int(cfg["batch"])
            cfg["max_steps"] = int(cfg["max_steps"])
            cfg["shaping"] = float(cfg["shaping"])
            cfg["seed"] = int(cfg["seed"])
            await rebuild()
            await send({"type":"cfg", "cfg": cfg})
            await warm()

        if mtype == "run":
            mode = data.get("mode","")
            if mode == "start":
                if task and not task.done():
                    continue
                running = True
                task = asyncio.create_task(loop())
            elif mode == "stop":
                running = False
            elif mode == "step":
                try:
                    agent.tune(gamma=cfg["gamma"], alpha=cfg["alpha"], epsilon=cfg["epsilon"], n_step=cfg["n_step"], eps_decay=cfg["eps_decay"])
                    env.set_shaping(cfg["shaping"])
                    out = agent.learn(batches=1, max_steps=cfg["max_steps"])
                    await emit_tick(metrics=out.get("metrics", {}), viz=out.get("viz", {}))
                except Exception as e:
                    await emit_tick(metrics={"error": str(e)}, viz={})
            elif mode == "reset":
                running = False
                await rebuild()
                await warm()

        if mtype == "infer":
            try:
                traj = agent.rollout_greedy(max_steps=cfg["max_steps"])
                await send({"type":"traj", "traj": traj})
            except Exception as e:
                await send({"type":"traj", "traj": {"error": str(e)}})

    running = False
    if task and not task.done():
        task.cancel()
    return sock

def main():
    app = web.Application()
    web_dir = os.path.join(os.path.dirname(__file__), "web")
    app["web_dir"] = web_dir
    app.router.add_get("/", index)
    app.router.add_get("/ws", ws)
    app.router.add_static("/web/", web_dir, show_index=False)
    web.run_app(app, host="127.0.0.1", port=8000)

if __name__ == "__main__":
    main()