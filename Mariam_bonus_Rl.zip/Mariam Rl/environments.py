import numpy as np

def list_envs():
    return [
        {"key": "GridWorld", "label": "GridWorld", "family": "discrete", "state": "grid", "action": "discrete"},
        {"key": "FrozenLake", "label": "FrozenLake", "family": "discrete", "state": "discrete", "action": "discrete"},
        {"key": "CartPole", "label": "CartPole", "family": "continuous", "state": "continuous->discrete", "action": "discrete"},
        {"key": "MountainCar", "label": "MountainCar", "family": "continuous", "state": "continuous->discrete", "action": "discrete"},
        {"key": "BreakoutMini", "label": "BreakoutMini", "family": "pixels-lite", "state": "continuous->discrete", "action": "discrete"},
        {"key": "Gym4ReaL", "label": "Gym4ReaL", "family": "continuous", "state": "continuous->discrete", "action": "discrete"},
    ]

def create_env(env_key: str, shaping: float = 0.0, seed: int = 0):
    if env_key == "GridWorld":
        return GridWorld(shaping=shaping, seed=seed)
    if env_key == "FrozenLake":
        return FrozenLake(shaping=shaping, seed=seed)
    if env_key == "CartPole":
        return CartPoleDisc(shaping=shaping, seed=seed)
    if env_key == "MountainCar":
        return MountainCarDisc(shaping=shaping, seed=seed)
    if env_key == "BreakoutMini":
        return BreakoutMini(shaping=shaping, seed=seed)
    if env_key == "Gym4ReaL":
        return Gym4ReaL(shaping=shaping, seed=seed)
    return GridWorld(shaping=shaping, seed=seed)

class EnvBase:
    key = "Base"
    discrete = True

    def reset(self):
        raise NotImplementedError

    def step(self, a: int):
        raise NotImplementedError

    def nS(self):
        raise NotImplementedError

    def nA(self):
        raise NotImplementedError

    def has_model(self):
        return False

    def model(self):
        return None

    def frame(self):
        return {}

    def snapshot(self):
        return {}

    def set_shaping(self, x: float):
        self.shaping = float(x)

class GridWorld(EnvBase):
    key = "GridWorld"
    discrete = True

    def __init__(self, w=6, h=6, shaping=0.0, seed=0):
        self.w = int(w)
        self.h = int(h)
        self.shaping = float(shaping)
        self.rng = np.random.default_rng(seed)
        self.walls = set([(1,1),(2,1),(3,1),(3,2),(3,3)])
        self.start = (0,0)
        self.goal = (5,5)
        self.reset()

    def nS(self):
        return self.w * self.h

    def nA(self):
        return 4

    def _s(self, x, y):
        return int(y*self.w + x)

    def _xy(self, s):
        return (int(s % self.w), int(s // self.w))

    def reset(self):
        self.agent = self.start
        self.t = 0
        return self._s(*self.agent)

    def has_model(self):
        return True

    def _manhattan(self, a, b):
        return abs(a[0]-b[0]) + abs(a[1]-b[1])

    def _reward(self, ns, done):
        base = 1.0 if done else -0.04
        x, y = self._xy(ns)
        shaped = self.shaping * (-self._manhattan((x,y), self.goal) / (self.w + self.h))
        return float(base + shaped)

    def model(self):
        P = {}
        for s in range(self.nS()):
            x, y = self._xy(s)
            P[s] = {}
            for a in range(self.nA()):
                nx, ny = x, y
                if a == 0: ny -= 1
                elif a == 1: nx += 1
                elif a == 2: ny += 1
                else: nx -= 1
                nx = int(np.clip(nx, 0, self.w-1))
                ny = int(np.clip(ny, 0, self.h-1))
                if (nx, ny) in self.walls:
                    nx, ny = x, y
                ns = self._s(nx, ny)
                done = (nx, ny) == self.goal
                P[s][a] = [(1.0, ns, self._reward(ns, done), bool(done))]
        return P

    def step(self, a: int):
        x, y = self.agent
        nx, ny = x, y
        if a == 0: ny -= 1
        elif a == 1: nx += 1
        elif a == 2: ny += 1
        else: nx -= 1
        nx = int(np.clip(nx, 0, self.w-1))
        ny = int(np.clip(ny, 0, self.h-1))
        if (nx, ny) in self.walls:
            nx, ny = x, y
        self.agent = (nx, ny)
        self.t += 1
        done = self.agent == self.goal
        ns = self._s(nx, ny)
        r = self._reward(ns, done)
        return int(ns), float(r), bool(done), {"t": int(self.t), "xy": [int(nx), int(ny)]}

    def frame(self):
        ax, ay = self.agent
        gx, gy = self.goal
        return {"kind":"grid","w":self.w,"h":self.h,"agent":[ax,ay],"goal":[gx,gy],"walls":[[x,y] for (x,y) in sorted(self.walls)]}

    def snapshot(self):
        return {"state": int(self._s(*self.agent)), "xy": list(self.agent), "goal": list(self.goal)}

class FrozenLake(EnvBase):
    key = "FrozenLake"
    discrete = True

    def __init__(self, shaping=0.0, seed=0):
        self.shaping = float(shaping)
        self.rng = np.random.default_rng(seed)
        self.map = ["SFFF","FHFH","FFFH","HFFG"]
        self.h = 4
        self.w = 4
        self.start = (0,0)
        self.goal = (3,3)
        self.reset()

    def nS(self):
        return self.w * self.h

    def nA(self):
        return 4

    def _s(self, x, y):
        return int(y*self.w + x)

    def _xy(self, s):
        return (int(s % self.w), int(s // self.w))

    def has_model(self):
        return True

    def _manhattan(self, a, b):
        return abs(a[0]-b[0]) + abs(a[1]-b[1])

    def _reward(self, ns, done, hit_hole=False):
        x, y = self._xy(ns)
        cell = self.map[y][x]
        base = 1.0 if cell == "G" else -0.01
        if hit_hole:
            base = -0.20
        shaped = self.shaping * (-self._manhattan((x,y), self.goal) / (self.w + self.h))
        return float(base + shaped)

    def model(self):
        P = {}
        for s in range(self.nS()):
            x, y = self._xy(s)
            cell = self.map[y][x]
            P[s] = {}
            for a in range(self.nA()):
                if cell == "G":
                    P[s][a] = [(1.0, s, self._reward(s, True, False), True)]
                    continue
                nxts = []
                for slip_a, prob in [(a,0.8), ((a+1)%4,0.1), ((a+3)%4,0.1)]:
                    nx, ny = x, y
                    if slip_a == 0: ny -= 1
                    elif slip_a == 1: nx += 1
                    elif slip_a == 2: ny += 1
                    else: nx -= 1
                    nx = int(np.clip(nx, 0, self.w-1))
                    ny = int(np.clip(ny, 0, self.h-1))
                    next_cell = self.map[ny][nx]
                    if next_cell == "H":
                        ns = s
                        done = False
                        r = self._reward(ns, done, True)
                        nxts.append((prob, ns, r, done))
                    else:
                        ns = self._s(nx, ny)
                        done = (next_cell == "G")
                        r = self._reward(ns, done, False)
                        nxts.append((prob, ns, r, bool(done)))
                P[s][a] = nxts
        return P

    def reset(self):
        self.agent = self.start
        self.t = 0
        return self._s(*self.agent)

    def step(self, a: int):
        P = self.model()
        s = self._s(*self.agent)
        choices = P[s][int(a)]
        probs = np.array([c[0] for c in choices], dtype=float)
        idx = int(self.rng.choice(len(choices), p=probs/probs.sum()))
        _, ns, r, done = choices[idx]
        x, y = self._xy(ns)
        self.agent = (x, y)
        self.t += 1
        return int(ns), float(r), bool(done), {"t": int(self.t), "cell": self.map[y][x], "xy": [int(x), int(y)]}

    def frame(self):
        ax, ay = self.agent
        return {"kind":"lake","w":self.w,"h":self.h,"agent":[ax,ay],"map":self.map}

    def snapshot(self):
        s = int(self._s(*self.agent))
        x, y = self._xy(s)
        return {"state": s, "xy":[x,y], "cell": self.map[y][x]}

class CartPoleDisc(EnvBase):
    key = "CartPole"
    discrete = False

    def __init__(self, shaping=0.0, seed=0):
        self.shaping = float(shaping)
        self.rng = np.random.default_rng(seed)
        self.g = 9.8
        self.mc = 1.0
        self.mp = 0.1
        self.total = self.mc + self.mp
        self.l = 0.5
        self.polemass_length = self.mp * self.l
        self.tau = 0.02
        self.x_threshold = 2.4
        self.theta_threshold = 12 * np.pi / 180
        self.bins = [7,7,9,9]
        self.low = np.array([-2.4, -3.0, -0.2095, -3.5], dtype=float)
        self.high = np.array([ 2.4,  3.0,  0.2095,  3.5], dtype=float)
        self.reset()

    def nA(self):
        return 2

    def nS(self):
        return int(np.prod(self.bins))

    def reset(self):
        self.state = self.rng.uniform(low=-0.05, high=0.05, size=(4,))
        self.t = 0
        return int(self._disc(self.state))

    def _disc(self, s):
        s = np.clip(s, self.low, self.high)
        idxs = []
        for i in range(4):
            edges = np.linspace(self.low[i], self.high[i], self.bins[i] + 1)
            b = int(np.digitize(s[i], edges) - 1)
            b = int(np.clip(b, 0, self.bins[i]-1))
            idxs.append(b)
        flat = 0
        mult = 1
        for i in range(4):
            flat += idxs[i] * mult
            mult *= self.bins[i]
        return int(flat)

    def step(self, a: int):
        x, xdot, th, thdot = self.state
        force = 10.0 if int(a) == 1 else -10.0
        costh = float(np.cos(th))
        sinth = float(np.sin(th))
        temp = (force + self.polemass_length * thdot * thdot * sinth) / self.total
        thacc = (self.g * sinth - costh * temp) / (self.l * (4.0/3.0 - self.mp * costh * costh / self.total))
        xacc = temp - self.polemass_length * thacc * costh / self.total
        x = x + self.tau * xdot
        xdot = xdot + self.tau * xacc
        th = th + self.tau * thdot
        thdot = thdot + self.tau * thacc
        self.state = np.array([x, xdot, th, thdot], dtype=float)
        self.t += 1
        done = (abs(x) > self.x_threshold) or (abs(th) > self.theta_threshold) or (self.t >= 500)
        base = 1.0
        shaped = self.shaping * (-(abs(th)/self.theta_threshold) - 0.2*(abs(x)/self.x_threshold))
        r = float(base + shaped)
        return int(self._disc(self.state)), float(r), bool(done), {"t": int(self.t), "raw": self.state.tolist()}

    def frame(self):
        x, _, th, _ = self.state
        return {"kind":"cartpole","x": float(x), "theta": float(th), "t": int(self.t)}

    def snapshot(self):
        return {"t": int(self.t), "raw": self.state.tolist(), "disc": int(self._disc(self.state))}

class MountainCarDisc(EnvBase):
    key = "MountainCar"
    discrete = False

    def __init__(self, shaping=0.0, seed=0):
        self.shaping = float(shaping)
        self.rng = np.random.default_rng(seed)
        self.min_pos = -1.2
        self.max_pos = 0.6
        self.max_speed = 0.07
        self.goal_pos = 0.5
        self.bins = [18,14]
        self.low = np.array([self.min_pos, -self.max_speed], dtype=float)
        self.high = np.array([self.max_pos, self.max_speed], dtype=float)
        self.reset()

    def nA(self):
        return 3

    def nS(self):
        return int(np.prod(self.bins))

    def reset(self):
        self.pos = float(self.rng.uniform(-0.6, -0.4))
        self.vel = 0.0
        self.t = 0
        return int(self._disc(np.array([self.pos, self.vel], dtype=float)))

    def _disc(self, s):
        s = np.clip(s, self.low, self.high)
        edges0 = np.linspace(self.low[0], self.high[0], self.bins[0] + 1)
        edges1 = np.linspace(self.low[1], self.high[1], self.bins[1] + 1)
        b0 = int(np.clip(np.digitize(s[0], edges0) - 1, 0, self.bins[0]-1))
        b1 = int(np.clip(np.digitize(s[1], edges1) - 1, 0, self.bins[1]-1))
        return int(b0 + b1*self.bins[0])

    def step(self, a: int):
        force = (int(a) - 1) * 0.001
        self.vel += force + float(np.cos(3*self.pos) * (-0.0025))
        self.vel = float(np.clip(self.vel, -self.max_speed, self.max_speed))
        self.pos += self.vel
        self.pos = float(np.clip(self.pos, self.min_pos, self.max_pos))
        if self.pos == self.min_pos and self.vel < 0:
            self.vel = 0.0
        self.t += 1
        done = (self.pos >= self.goal_pos) or (self.t >= 400)
        base = 0.0 if done else -1.0
        shaped = self.shaping * (self.pos - self.goal_pos)
        r = float(base + shaped)
        sdisc = int(self._disc(np.array([self.pos, self.vel], dtype=float)))
        return sdisc, float(r), bool(done), {"t": int(self.t), "raw": [float(self.pos), float(self.vel)]}

    def frame(self):
        return {"kind":"mountaincar","pos": float(self.pos), "vel": float(self.vel), "t": int(self.t)}

    def snapshot(self):
        return {"t": int(self.t), "raw": [float(self.pos), float(self.vel)], "disc": int(self._disc(np.array([self.pos, self.vel])))}

class BreakoutMini(EnvBase):
    key = "BreakoutMini"
    discrete = False

    def __init__(self, shaping=0.0, seed=0):
        self.shaping = float(shaping)
        self.rng = np.random.default_rng(seed)
        self.W = 320
        self.H = 220
        self.paddle_w = 64
        self.paddle_h = 10
        self.ball_r = 6
        self.br_cols = 10
        self.br_rows = 4
        self.br_w = 28
        self.br_h = 12
        self.br_gap = 4
        self.obs_bins = [12, 8, 9, 9]
        self.reset()

    def nA(self):
        return 3

    def nS(self):
        return int(np.prod(self.obs_bins))

    def reset(self):
        self.last_hit = ""
        self.px = self.W / 2
        self.bx = self.W / 2
        self.by = self.H * 0.62
        ang = self.rng.uniform(0.82, 1.18) * np.pi
        sp = 3.2
        self.bvx = float(np.cos(ang) * sp)
        self.bvy = float(np.sin(ang) * sp)
        self.bricks = np.ones((self.br_rows, self.br_cols), dtype=int)
        self.t = 0
        return int(self._disc())

    def _disc(self):
        x = self.bx / self.W
        y = self.by / self.H
        vx = (self.bvx + 4) / 8
        vy = (self.bvy + 4) / 8
        vals = [x, y, vx, vy]
        bins = self.obs_bins
        idxs = []
        for v, b in zip(vals, bins):
            i = int(np.clip(np.floor(v * b), 0, b - 1))
            idxs.append(i)
        flat = idxs[0] + idxs[1]*bins[0] + idxs[2]*bins[0]*bins[1] + idxs[3]*bins[0]*bins[1]*bins[2]
        return int(flat)

    def step(self, a: int):
        if int(a) == 0:
            self.px -= 7
        elif int(a) == 2:
            self.px += 7
        self.px = float(np.clip(self.px, self.paddle_w/2, self.W - self.paddle_w/2))

        self.bx += self.bvx
        self.by += self.bvy

        if self.bx <= self.ball_r or self.bx >= self.W - self.ball_r:
            self.bvx *= -1
            self.last_hit = "wall"
        if self.by <= self.ball_r:
            self.bvy *= -1
            self.last_hit = "wall"

        r = 0.0
        done = False

        paddle_y = self.H - 22
        if (paddle_y - self.ball_r <= self.by <= paddle_y + self.paddle_h + self.ball_r) and (abs(self.bx - self.px) <= self.paddle_w/2 + self.ball_r) and self.bvy > 0:
            self.last_hit = "paddle"
            self.bvy *= -1
            hit = (self.bx - self.px) / (self.paddle_w/2)
            self.bvx += float(hit) * 0.8

        hit_brick = False
        top_y = 26
        for rr in range(self.br_rows):
            for cc in range(self.br_cols):
                if self.bricks[rr, cc] == 0:
                    continue
                bx0 = 14 + cc*(self.br_w + self.br_gap)
                by0 = top_y + rr*(self.br_h + self.br_gap)
                if (bx0 - self.ball_r <= self.bx <= bx0 + self.br_w + self.ball_r) and (by0 - self.ball_r <= self.by <= by0 + self.br_h + self.ball_r):
                    self.bricks[rr, cc] = 0
                    self.bvy *= -1
                    r += 1.0
                    self.last_hit = "brick"
                    hit_brick = True
                    break
            if hit_brick:
                break

        if self.by >= self.H - 5:
            done = True
            self.last_hit = "miss"
            r -= 1.0
        if self.bricks.sum() == 0:
            done = True
            r += 2.0

        self.t += 1
        if self.t >= 1200:
            done = True

        shaped = self.shaping * (0.0 if hit_brick else -0.002)
        r = float(r + shaped)

        return int(self._disc()), float(r), bool(done), {"t": int(self.t)}

    def frame(self):
        bricks_list = []
        top_y = 26
        for rr in range(self.br_rows):
            for cc in range(self.br_cols):
                if self.bricks[rr, cc] == 0:
                    continue
                x = 14 + cc*(self.br_w + self.br_gap)
                y = top_y + rr*(self.br_h + self.br_gap)
                bricks_list.append([x, y, self.br_w, self.br_h])
        return {"kind":"breakout","W":self.W,"H":self.H,
                "paddle":[float(self.px), float(self.H - 22), float(self.paddle_w), float(self.paddle_h)],
                "ball":[float(self.bx), float(self.by), float(self.ball_r)],
                "bricks": bricks_list,
                "t": int(self.t),
                "last_hit": self.last_hit}

    def snapshot(self):
        return {"t": int(self.t), "bricks_left": int(self.bricks.sum())}

class Gym4ReaL(EnvBase):
    key = "Gym4ReaL"
    discrete = False

    def __init__(self, shaping=0.0, seed=0):
        self.shaping = float(shaping)
        self.rng = np.random.default_rng(seed)
        self.W = 22.0
        self.H = 14.0
        self.goal = np.array([19.0, 7.0], dtype=float)
        self.bins = [22, 14, 12]
        self.reset()

    def nA(self):
        return 4

    def nS(self):
        return int(np.prod(self.bins))

    def reset(self):
        self.pos = np.array([3.0, 7.0], dtype=float)
        self.heading = float(self.rng.uniform(-0.4, 0.4))
        self.speed = 0.0
        self.t = 0
        self.obstacles = [
            (8.0, 5.0, 1.2),
            (10.5, 9.0, 1.4),
            (14.0, 7.0, 1.6),
            (16.8, 4.5, 1.2),
            (16.5, 10.0, 1.2),
        ]
        return int(self._disc())

    def _disc(self):
        x, y = self.pos
        h = self.heading
        bx = int(np.clip(np.floor((x / self.W) * self.bins[0]), 0, self.bins[0]-1))
        by = int(np.clip(np.floor((y / self.H) * self.bins[1]), 0, self.bins[1]-1))
        hh = (h + np.pi) / (2*np.pi)
        bh = int(np.clip(np.floor(hh * self.bins[2]), 0, self.bins[2]-1))
        return int(bx + by*self.bins[0] + bh*self.bins[0]*self.bins[1])

    def _dist_obs(self, p):
        dmin = 1e9
        for ox, oy, rr in self.obstacles:
            d = float(np.hypot(p[0]-ox, p[1]-oy) - rr)
            dmin = min(dmin, d)
        return dmin

    def step(self, a: int):
        a = int(a)
        if a == 1:
            self.heading -= 0.18
        elif a == 2:
            self.heading += 0.18
        self.heading = float(np.clip(self.heading, -np.pi, np.pi))

        if a == 0:
            self.speed += 0.07
        elif a == 3:
            self.speed -= 0.12
        else:
            self.speed *= 0.97
        self.speed = float(np.clip(self.speed, 0.0, 0.9))

        v = np.array([np.cos(self.heading), np.sin(self.heading)], dtype=float) * self.speed
        nxt = self.pos + v
        nxt[0] = float(np.clip(nxt[0], 0.6, self.W-0.6))
        nxt[1] = float(np.clip(nxt[1], 0.6, self.H-0.6))

        dmin = self._dist_obs(nxt)
        collided = dmin < 0.05

        self.pos = nxt
        self.t += 1

        dist_goal = float(np.hypot(self.pos[0]-self.goal[0], self.pos[1]-self.goal[1]))
        done = (dist_goal < 0.9) or collided or (self.t >= 500)

        base = -0.01
        if dist_goal < 0.9:
            base += 1.3
        if collided:
            base -= 1.5

        shaped = self.shaping * (-dist_goal / (self.W + self.H))
        r = float(base + shaped)

        info = {"t": int(self.t), "dist_goal": float(dist_goal), "collided": bool(collided)}
        return int(self._disc()), float(r), bool(done), info

    def frame(self):
        return {
            "kind":"gym4real",
            "W": float(self.W),
            "H": float(self.H),
            "pos":[float(self.pos[0]), float(self.pos[1])],
            "heading": float(self.heading),
            "goal":[float(self.goal[0]), float(self.goal[1])],
            "obstacles":[[float(a),float(b),float(c)] for (a,b,c) in self.obstacles],
            "t": int(self.t),
        }

    def snapshot(self):
        return {"t": int(self.t), "pos":[float(self.pos[0]), float(self.pos[1])], "heading": float(self.heading)}
