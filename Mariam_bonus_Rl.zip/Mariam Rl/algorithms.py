import numpy as np

def list_algorithms():
    return [
        {"key":"PolicyIter", "label":"Policy Iteration", "family":"dp"},
        {"key":"ValueIter", "label":"Value Iteration", "family":"dp"},
        {"key":"PolicyEval", "label":"Policy Evaluation", "family":"dp"},
        {"key":"MC", "label":"Monte Carlo (First-Visit)", "family":"mf"},
        {"key":"TD0", "label":"TD(0)", "family":"mf"},
        {"key":"NStepTD", "label":"n-step TD", "family":"mf"},
        {"key":"SARSA", "label":"SARSA", "family":"mf"},
        {"key":"QLearn", "label":"Q-Learning", "family":"mf"},
    ]

def policy_overlay(pi, env):
    if getattr(env, "key", "") not in ["GridWorld", "FrozenLake"]:
        return []
    w = int(env.w)
    h = int(env.h)
    out = []
    for s in range(env.nS()):
        x, y = (s % w, s // w)
        out.append([int(x), int(y), int(pi[s])])
    return out

class AgentCore:
    key = "Base"

    def __init__(self, env, gamma=0.99, alpha=0.2, epsilon=0.15, n_step=5, eps_decay=0.9995):
        self.env = env
        self.gamma = float(gamma)
        self.alpha = float(alpha)
        self.epsilon = float(epsilon)
        self.n_step = int(n_step)
        self.eps_decay = float(eps_decay)
        self.episode = 0
        self.history = []

    def _clamp_s(self, s):
        try:
            s = int(s)
        except Exception:
            s = 0
        try:
            n = int(self.env.nS())
        except Exception:
            return max(0, s)
        if n <= 1:
            return 0
        if s < 0:
            return 0
        if s >= n:
            return n - 1
        return s

    def tune(self, gamma=None, alpha=None, epsilon=None, n_step=None, eps_decay=None):
        if gamma is not None:
            self.gamma = float(gamma)
        if alpha is not None:
            self.alpha = float(alpha)
        if epsilon is not None:
            self.epsilon = float(epsilon)
        if n_step is not None:
            self.n_step = int(n_step)
        if eps_decay is not None:
            self.eps_decay = float(eps_decay)

    def act_greedy(self, s):
        return 0

    def learn(self, batches=1, max_steps=200):
        return {"metrics": {"episode": int(self.episode)}, "viz": {}}

    def rollout_greedy(self, max_steps=200):
        s = self._clamp_s(self.env.reset())
        traj = []
        total = 0.0
        for t in range(int(max_steps)):
            a = int(self.act_greedy(s))
            ns, r, done, info = self.env.step(a)
            ns = self._clamp_s(ns)
            traj.append({"s": int(s), "a": int(a), "r": float(r), "ns": int(ns), "done": bool(done), "frame": self.env.frame(), "t": int(t)})
            total += float(r)
            s = ns
            if done:
                break
        return {"return": float(total), "steps": len(traj), "traj": traj}

class PolicyIter(AgentCore):
    key = "PolicyIter"

    def __init__(self, env, gamma=0.99, **kw):
        super().__init__(env, gamma=gamma)
        self.V = np.zeros(env.nS(), dtype=float)
        self.pi = np.zeros(env.nS(), dtype=int)
        self.P = env.model()

    def _eval(self, iters=35):
        for _ in range(int(iters)):
            Vn = np.zeros_like(self.V)
            for s in range(self.env.nS()):
                a = int(self.pi[s])
                v = 0.0
                for p, ns, r, done in self.P[s][a]:
                    v += float(p) * (float(r) + (0.0 if done else self.gamma * self.V[int(ns)]))
                Vn[s] = v
            self.V = Vn

    def _improve(self):
        stable = True
        for s in range(self.env.nS()):
            old = int(self.pi[s])
            best_a = 0
            best_q = -1e18
            for a in range(self.env.nA()):
                q = 0.0
                for p, ns, r, done in self.P[s][a]:
                    q += float(p) * (float(r) + (0.0 if done else self.gamma * self.V[int(ns)]))
                if q > best_q:
                    best_q = q
                    best_a = int(a)
            self.pi[s] = int(best_a)
            if int(self.pi[s]) != old:
                stable = False
        return stable

    def learn(self, batches=1, max_steps=200):
        for _ in range(int(batches)):
            self._eval(iters=35)
            stable = self._improve()
            self.episode += 1
            self.history.append(float(self.V[0]))
            if stable:
                break
        viz = {"V": self.V.tolist(), "policy": policy_overlay(self.pi, self.env)}
        return {"metrics": {"episode": int(self.episode), "score": float(self.V[0])}, "viz": viz}

    def act_greedy(self, s):
        return int(self.pi[int(s)])

class ValueIter(AgentCore):
    key = "ValueIter"

    def __init__(self, env, gamma=0.99, **kw):
        super().__init__(env, gamma=gamma)
        self.V = np.zeros(env.nS(), dtype=float)
        self.pi = np.zeros(env.nS(), dtype=int)
        self.P = env.model()

    def learn(self, batches=1, max_steps=200):
        for _ in range(int(batches)):
            Vn = np.zeros_like(self.V)
            for s in range(self.env.nS()):
                best_q = -1e18
                best_a = 0
                for a in range(self.env.nA()):
                    q = 0.0
                    for p, ns, r, done in self.P[s][a]:
                        q += float(p) * (float(r) + (0.0 if done else self.gamma * self.V[int(ns)]))
                    if q > best_q:
                        best_q = q
                        best_a = int(a)
                Vn[s] = float(best_q)
                self.pi[s] = int(best_a)
            self.V = Vn
            self.episode += 1
            self.history.append(float(self.V[0]))
        viz = {"V": self.V.tolist(), "policy": policy_overlay(self.pi, self.env)}
        return {"metrics": {"episode": int(self.episode), "score": float(self.V[0])}, "viz": viz}

    def act_greedy(self, s):
        return int(self.pi[int(s)])


class PolicyEval(AgentCore):
    key = "PolicyEval"

    def __init__(self, env, gamma=0.99, **kw):
        super().__init__(env, gamma=gamma)
        self.V = np.zeros(env.nS(), dtype=float)
        # Fixed (random) deterministic policy for evaluation/visualization
        self.pi = np.random.randint(0, env.nA(), size=env.nS(), dtype=int)
        self.P = env.model()

    def learn(self, batches=1, max_steps=200):
        # Iterative policy evaluation for the current policy self.pi
        iters = 35
        for _ in range(int(batches)):
            for _ in range(int(iters)):
                Vn = np.zeros_like(self.V)
                for s in range(self.env.nS()):
                    a = int(self.pi[s])
                    v = 0.0
                    for p, ns, r, done in self.P[s][a]:
                        v += float(p) * (float(r) + (0.0 if done else self.gamma * self.V[int(ns)]))
                    Vn[s] = float(v)
                self.V = Vn
            self.episode += 1
            self.history.append(float(self.V[0]))
        viz = {"V": self.V.tolist(), "policy": policy_overlay(self.pi, self.env)}
        return {"metrics": {"episode": int(self.episode), "score": float(self.V[0])}, "viz": viz}

    def act_greedy(self, s):
        return int(self.pi[int(s)])

class TabControl(AgentCore):
    def __init__(self, env, gamma=0.99, alpha=0.2, epsilon=0.15, n_step=5, eps_decay=0.9995):
        super().__init__(env, gamma=gamma, alpha=alpha, epsilon=epsilon, n_step=n_step, eps_decay=eps_decay)
        self.Q = np.zeros((env.nS(), env.nA()), dtype=float)

    def _egreedy(self, s):
        if np.random.random() < self.epsilon:
            return int(np.random.randint(self.env.nA()))
        return int(np.argmax(self.Q[int(s)]))

    def act_greedy(self, s):
        return int(np.argmax(self.Q[int(s)]))

class MC( TabControl ):
    key = "MC"
    def learn(self, batches=1, max_steps=200):
        for _ in range(int(batches)):
            s = self._clamp_s(self.env.reset())
            ep = []
            total = 0.0
            for _t in range(int(max_steps)):
                a = self._egreedy(s)
                ns, r, done, _ = self.env.step(a)
                ns = self._clamp_s(ns)
                ep.append((int(s), int(a), float(r)))
                total += float(r)
                s = ns
                if done:
                    break
            G = 0.0
            seen = set()
            for (s, a, r) in reversed(ep):
                G = float(r) + self.gamma * G
                k = (int(s), int(a))
                if k in seen:
                    continue
                seen.add(k)
                self.Q[int(s), int(a)] += self.alpha * (G - self.Q[int(s), int(a)])
            self.episode += 1
            self.epsilon = max(0.01, self.epsilon * self.eps_decay)
            self.history.append(float(total))
        return {"metrics": {"episode": int(self.episode), "return": float(self.history[-1]), "epsilon": float(self.epsilon)},
                "viz": {"Qmax": self.Q.max(axis=1).tolist()}}

class TD0( TabControl ):
    key = "TD0"
    def learn(self, batches=1, max_steps=200):
        for _ in range(int(batches)):
            s = self._clamp_s(self.env.reset())
            total = 0.0
            for _t in range(int(max_steps)):
                a = self._egreedy(s)
                ns, r, done, _ = self.env.step(a)
                ns = self._clamp_s(ns)
                td = float(r) + (0.0 if done else self.gamma * self.Q[int(ns)].max()) - self.Q[int(s), int(a)]
                self.Q[int(s), int(a)] += self.alpha * td
                total += float(r)
                s = ns
                if done:
                    break
            self.episode += 1
            self.epsilon = max(0.01, self.epsilon * self.eps_decay)
            self.history.append(float(total))
        return {"metrics": {"episode": int(self.episode), "return": float(self.history[-1]), "epsilon": float(self.epsilon)},
                "viz": {"Qmax": self.Q.max(axis=1).tolist()}}

class NStepTD( TabControl ):
    key = "NStepTD"
    def learn(self, batches=1, max_steps=200):
        n = max(1, int(self.n_step))
        for _ in range(int(batches)):
            s0 = self._clamp_s(self.env.reset())
            S = [int(s0)]
            A = []
            R = [0.0]
            total = 0.0
            T = 10**9
            t = 0
            A.append(int(self._egreedy(S[0])))
            while True:
                if t < T:
                    ns, r, done, _ = self.env.step(A[t])
                    ns = self._clamp_s(ns)
                    S.append(int(ns))
                    R.append(float(r))
                    total += float(r)
                    if done or (t + 1 >= int(max_steps)):
                        T = t + 1
                    else:
                        A.append(int(self._egreedy(ns)))
                tau = t - n + 1
                if tau >= 0:
                    G = 0.0
                    for i in range(tau + 1, min(tau + n, T) + 1):
                        G += (self.gamma ** (i - tau - 1)) * R[i]
                    if tau + n < T:
                        G += (self.gamma ** n) * self.Q[int(S[tau + n])].max()
                    s_tau = int(S[tau])
                    a_tau = int(A[tau])
                    self.Q[s_tau, a_tau] += self.alpha * (G - self.Q[s_tau, a_tau])
                if tau == T - 1:
                    break
                t += 1
            self.episode += 1
            self.epsilon = max(0.01, self.epsilon * self.eps_decay)
            self.history.append(float(total))
        return {"metrics": {"episode": int(self.episode), "return": float(self.history[-1]), "epsilon": float(self.epsilon), "n": int(n)},
                "viz": {"Qmax": self.Q.max(axis=1).tolist()}}

class SARSA( TabControl ):
    key = "SARSA"
    def learn(self, batches=1, max_steps=200):
        for _ in range(int(batches)):
            s = self._clamp_s(self.env.reset())
            a = int(self._egreedy(s))
            total = 0.0
            for _t in range(int(max_steps)):
                ns, r, done, _ = self.env.step(a)
                ns = self._clamp_s(ns)
                na = int(self._egreedy(ns))
                td = float(r) + (0.0 if done else self.gamma * self.Q[int(ns), int(na)]) - self.Q[int(s), int(a)]
                self.Q[int(s), int(a)] += self.alpha * td
                total += float(r)
                s, a = ns, na
                if done:
                    break
            self.episode += 1
            self.epsilon = max(0.01, self.epsilon * self.eps_decay)
            self.history.append(float(total))
        return {"metrics": {"episode": int(self.episode), "return": float(self.history[-1]), "epsilon": float(self.epsilon)},
                "viz": {"Qmax": self.Q.max(axis=1).tolist()}}

class QLearn( TabControl ):
    key = "QLearn"
    def learn(self, batches=1, max_steps=200):
        for _ in range(int(batches)):
            s = self._clamp_s(self.env.reset())
            total = 0.0
            for _t in range(int(max_steps)):
                a = int(self._egreedy(s))
                ns, r, done, _ = self.env.step(a)
                ns = self._clamp_s(ns)
                td = float(r) + (0.0 if done else self.gamma * self.Q[int(ns)].max()) - self.Q[int(s), int(a)]
                self.Q[int(s), int(a)] += self.alpha * td
                total += float(r)
                s = ns
                if done:
                    break
            self.episode += 1
            self.epsilon = max(0.01, self.epsilon * self.eps_decay)
            self.history.append(float(total))
        return {"metrics": {"episode": int(self.episode), "return": float(self.history[-1]), "epsilon": float(self.epsilon)},
                "viz": {"Qmax": self.Q.max(axis=1).tolist()}}