function roundRect(ctx, x, y, w, h, r) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

(() => {
  const $ = (id) => document.getElementById(id);
  const wsUrl =
    (location.protocol === "https:" ? "wss://" : "ws://") +
    location.host +
    "/ws";
  const ws = new WebSocket(wsUrl);

  const envSel = $("env");
  const algoSel = $("algo");

  const gamma = $("gamma");
  const alpha = $("alpha");
  const epsilon = $("epsilon");
  const epsDecay = $("epsDecay");
  const nstep = $("nstep");
  const shaping = $("shaping");
  const batch = $("batch");
  const maxSteps = $("maxSteps");
  const seed = $("seed");

  const start = $("start");
  const stop = $("stop");
  const step = $("step");
  const reset = $("reset");
  const infer = $("infer");

  const metrics = $("metrics");
  const statusText = $("statusText");

  const main = $("main");
  const heat = $("heat");
  const plot = $("plot");

  const toast = $("toast");
  const showToast = (t) => {
    toast.textContent = t;
    toast.hidden = false;
    setTimeout(() => (toast.hidden = true), 1800);
  };

  let spec = { envs: [], algos: [] };
  let cfg = {};
  let returns = [];

  const anim = { queue: [], playing: false, ms: 80, lastAgent: null };

  const fitCanvas = () => {
    const wrap = document.querySelector(".canvWrap");
    if (!wrap) return;
    const rect = wrap.getBoundingClientRect();
    const ratio = Math.max(1, Math.floor(window.devicePixelRatio || 1));
    const w = Math.max(820, Math.floor(rect.width * ratio));
    const h = document.body.classList.contains("bigMode")
      ? Math.floor(620 * ratio)
      : Math.floor(440 * ratio);
    main.width = w;
    main.height = h;
  };
  window.addEventListener("resize", () => fitCanvas());

  const isTabular = (k) => k === "GridWorld" || k === "FrozenLake";
  const isDP = (k) => k === "PolicyIter" || k === "ValueIter";

  const rebuildSelects = () => {
    envSel.innerHTML = spec.envs
      .map((e) => `<option value="${e.key}">${e.label}</option>`)
      .join("");
    algoSel.innerHTML = spec.algos
      .map((a) => `<option value="${a.key}">${a.label}</option>`)
      .join("");
  };

  const applyCfg = (c) => {
    fitCanvas();
    cfg = c;
    envSel.value = c.env;
    algoSel.value = c.algo;
    gamma.value = c.gamma;
    alpha.value = c.alpha;
    epsilon.value = c.epsilon;
    epsDecay.value = c.eps_decay;
    nstep.value = c.n_step;
    shaping.value = c.shaping;
    batch.value = c.batch;
    maxSteps.value = c.max_steps;
    seed.value = c.seed;
  };

  const patch = () => ({
    env: envSel.value,
    algo: algoSel.value,
    gamma: parseFloat(gamma.value || "0.99"),
    alpha: parseFloat(alpha.value || "0.2"),
    epsilon: parseFloat(epsilon.value || "0.15"),
    eps_decay: parseFloat(epsDecay.value || "0.9995"),
    n_step: parseInt(nstep.value || "5", 10),
    shaping: parseFloat(shaping.value || "0"),
    batch: parseInt(batch.value || "2", 10),
    max_steps: parseInt(maxSteps.value || "200", 10),
    seed: parseInt(seed.value || "0", 10),
  });

  const sendCfg = () => {
    let p = patch();
    if (isDP(p.algo) && !isTabular(p.env)) {
      p.algo = "TD0";
      algoSel.value = "TD0";
      showToast("DP works only on GridWorld/FrozenLake → switched to TD(0)");
    }
    ws.send(JSON.stringify({ type: "cfg", patch: p }));
  };

  [
    envSel,
    algoSel,
    gamma,
    alpha,
    epsilon,
    epsDecay,
    nstep,
    shaping,
    batch,
    maxSteps,
    seed,
  ].forEach((el) => el.addEventListener("change", sendCfg));

  start.onclick = () => ws.send(JSON.stringify({ type: "run", mode: "start" }));
  stop.onclick = () => ws.send(JSON.stringify({ type: "run", mode: "stop" }));
  step.onclick = () => ws.send(JSON.stringify({ type: "run", mode: "step" }));
  reset.onclick = () => ws.send(JSON.stringify({ type: "run", mode: "reset" }));
  infer.onclick = () => ws.send(JSON.stringify({ type: "infer" }));

  function isHole(frame, x, y) {
    if (!frame || frame.kind !== "lake") return false;
    const row = frame.map?.[y];
    const ch = row ? row[x] : "F";
    return ch === "H";
  }

  function bfsPath(frame, start, end) {
    const W = frame.w | 0;
    const H = frame.h | 0;
    if (start[0] === end[0] && start[1] === end[1]) return [start];

    const queue = [[start]];
    const visited = new Set();
    visited.add(`${start[0]},${start[1]}`);

    const getNeighbors = (x, y) => {
      const res = [];
      const dirs = [[0, 1], [0, -1], [1, 0], [-1, 0]];
      for (const [dx, dy] of dirs) {
        const nx = x + dx, ny = y + dy;
        if (nx >= 0 && nx < W && ny >= 0 && ny < H) {
          if (frame.kind === "grid" && frame.walls) {
            const isWall = frame.walls.some(w => w[0] === nx && w[1] === ny);
            if (isWall) continue;
          }
          res.push([nx, ny]);
        }
      }
      return res;
    };

    while (queue.length > 0) {
      const path = queue.shift();
      const [cx, cy] = path[path.length - 1];

      const neighbors = getNeighbors(cx, cy);
      for (const n of neighbors) {
        if (n[0] === end[0] && n[1] === end[1]) {
          return [...path, n];
        }
        const key = `${n[0]},${n[1]}`;
        if (!visited.has(key)) {
          visited.add(key);
          queue.push([...path, n]);
        }
      }
    }
    return [start];
  }

  function pump() {
    if (!anim.queue.length) {
      anim.playing = false;
      return;
    }
    anim.playing = true;
    const item = anim.queue.shift();
    const ctx = main.getContext("2d");
    const f = item.frame;

    document.body.classList.toggle("bigMode", f.kind === "breakout");
    fitCanvas();

    if (f.kind === "grid") drawGrid(ctx, f, item.policy, item.heatArr);
    else if (f.kind === "lake") drawLake(ctx, f, item.policy, item.heatArr);
    else if (f.kind === "cartpole") drawCartPole(ctx, f);
    else if (f.kind === "mountaincar") drawMountain(ctx, f);
    else if (f.kind === "breakout") drawBreakoutClean(ctx, f);
    else if (f.kind === "gym4real") drawGym4Real(ctx, f);
    else ctx.clearRect(0, 0, main.width, main.height);

    drawHeat(item.heatArr);
    drawPlot(returns);

    setTimeout(pump, anim.ms);
  }

  function enqueueGridSteps(frame, policy, heatArr) {
    if (!frame || !frame.kind) return;

    const target = frame.agent;
    if (!Array.isArray(target) || target.length < 2) {
      anim.queue.push({ frame, policy, heatArr });
      if (!anim.playing) pump();
      return;
    }

    const prev = Array.isArray(anim.lastAgent) ? anim.lastAgent : target;

    let path = [];
    if (frame.kind === "grid") {
      path = bfsPath(frame, [prev[0] | 0, prev[1] | 0], [target[0] | 0, target[1] | 0]);
    } else if (frame.kind === "lake") {
      if (isHole(frame, target[0], target[1])) {
         path = [target];
      } else {
         path = bfsPath(frame, [prev[0] | 0, prev[1] | 0], [target[0] | 0, target[1] | 0]);
      }
    }

    for (let i = 0; i < path.length; i++) {
      const xy = path[i];
      const stepFrame = { ...frame, agent: [xy[0], xy[1]] };
      anim.queue.push({ frame: stepFrame, policy, heatArr });
    }

    anim.lastAgent = [target[0], target[1]];

    if (!anim.playing) pump();
  }

  const drawHeat = (arr) => {
    if (!heat) return;
    const ctx = heat.getContext("2d");
    const W = heat.width,
      H = heat.height;
    ctx.clearRect(0, 0, W, H);
    if (!arr || !arr.length) return;
    const n = arr.length;
    const cols = Math.ceil(Math.sqrt(n));
    const rows = Math.ceil(n / cols);
    const cw = W / cols,
      ch = H / rows;
    const min = Math.min(...arr),
      max = Math.max(...arr);
    for (let i = 0; i < n; i++) {
      const t = (arr[i] - min) / (max - min + 1e-9);
      const a = 0.08 + 0.82 * t;
      ctx.fillStyle = `rgba(59,130,246,${a})`;
      const x = (i % cols) * cw;
      const y = Math.floor(i / cols) * ch;
      ctx.fillRect(x + 1, y + 1, cw - 2, ch - 2);
    }
    ctx.fillStyle = "rgba(167,183,216,.9)";
    ctx.font = "12px system-ui";
    ctx.fillText("state heat", 10, H - 10);
  };

  const drawPlot = (series) => {
    const ctx = plot.getContext("2d");
    const W = plot.width,
      H = plot.height;
    ctx.clearRect(0, 0, W, H);
    if (!series || series.length < 2) return;
    const n = Math.min(240, series.length);
    const data = series.slice(series.length - n);
    const min = Math.min(...data),
      max = Math.max(...data);
    const pad = 22;
    ctx.strokeStyle = "rgba(44,74,140,.55)";
    ctx.lineWidth = 1;
    ctx.strokeRect(pad, pad, W - pad * 2, H - pad * 2);

    ctx.strokeStyle = "rgba(34,211,238,.85)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    data.forEach((v, i) => {
      const x = pad + (i / (n - 1)) * (W - pad * 2);
      const y = pad + (1 - (v - min) / (max - min + 1e-9)) * (H - pad * 2);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    ctx.fillStyle = "rgba(167,183,216,.9)";
    ctx.font = "12px system-ui";
    ctx.fillText(`min ${min.toFixed(2)} | max ${max.toFixed(2)}`, pad, 14);
  };

  const drawGrid = (ctx, f, policy, heatArr) => {
    const W = main.width,
      H = main.height;
    ctx.clearRect(0, 0, W, H);

    const pad = 34;
    const cellW = (W - pad * 2) / f.w;
    const cellH = (H - pad * 2) / f.h;

    const g = ctx.createRadialGradient(
      W * 0.32,
      H * 0.18,
      16,
      W * 0.32,
      H * 0.18,
      W * 0.82
    );
    g.addColorStop(0, "rgba(59,130,246,.22)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    if (heatArr && heatArr.length === f.w * f.h) {
      const mn = Math.min(...heatArr),
        mx = Math.max(...heatArr);
      for (let y = 0; y < f.h; y++) {
        for (let x = 0; x < f.w; x++) {
          const v = heatArr[y * f.w + x];
          const t = (v - mn) / (mx - mn + 1e-9);
          ctx.fillStyle = `rgba(34,211,238,${0.05 + 0.35 * t})`;
          ctx.fillRect(pad + x * cellW, pad + y * cellH, cellW, cellH);
        }
      }
    }

    ctx.strokeStyle = "rgba(44,74,140,.75)";
    ctx.lineWidth = 1.4;
    for (let i = 0; i <= f.w; i++) {
      ctx.beginPath();
      ctx.moveTo(pad + i * cellW, pad);
      ctx.lineTo(pad + i * cellW, pad + f.h * cellH);
      ctx.stroke();
    }
    for (let j = 0; j <= f.h; j++) {
      ctx.beginPath();
      ctx.moveTo(pad, pad + j * cellH);
      ctx.lineTo(pad + f.w * cellW, pad + j * cellH);
      ctx.stroke();
    }

    for (const w of f.walls) {
      const x = w[0],
        y = w[1];
      ctx.fillStyle = "rgba(245,158,11,.14)";
      ctx.strokeStyle = "rgba(245,158,11,.45)";
      ctx.lineWidth = 2;
      ctx.fillRect(
        pad + x * cellW + 2,
        pad + y * cellH + 2,
        cellW - 4,
        cellH - 4
      );
      ctx.strokeRect(
        pad + x * cellW + 2,
        pad + y * cellH + 2,
        cellW - 4,
        cellH - 4
      );
    }

    const gx = f.goal[0],
      gy = f.goal[1];
    const ax = f.agent[0],
      ay = f.agent[1];

    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const size = Math.min(cellW, cellH) * 0.75;
    ctx.font = `${size}px system-ui`;

    const drawOutlinedEmoji = (emoji, x, y) => {
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(0,0,0,0.85)";
      ctx.strokeText(emoji, x, y);
      ctx.lineWidth = 2;
      ctx.strokeStyle = "rgba(255,255,255,0.75)";
      ctx.strokeText(emoji, x, y);
      ctx.fillStyle = "#ffffff";
      ctx.fillText(emoji, x, y);
    };

    drawOutlinedEmoji("🧀", pad + (gx + 0.5) * cellW, pad + (gy + 0.5) * cellH);
    drawOutlinedEmoji("🐭", pad + (ax + 0.5) * cellW, pad + (ay + 0.5) * cellH);

    if (policy && policy.length === f.w * f.h) {
      ctx.strokeStyle = "rgba(96,165,250,.75)";
      ctx.fillStyle = "rgba(96,165,250,.75)";
      for (const p of policy) {
        const x = p[0],
          y = p[1],
          a = p[2];
        const cx = pad + (x + 0.5) * cellW;
        const cy = pad + (y + 0.5) * cellH;
        const len = Math.min(cellW, cellH) * 0.22;
        let dx = 0,
          dy = 0;
        if (a === 0) dy = -1;
        if (a === 1) dx = 1;
        if (a === 2) dy = 1;
        if (a === 3) dx = -1;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + dx * len, cy + dy * len);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(cx + dx * len, cy + dy * len, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  };

  const drawLake = (ctx, f, policy, heatArr) => {
    const W = main.width,
      H = main.height;
    ctx.clearRect(0, 0, W, H);

    const pad = 34;
    const cellW = (W - pad * 2) / f.w;
    const cellH = (H - pad * 2) / f.h;

    const g = ctx.createRadialGradient(
      W * 0.22,
      H * 0.18,
      16,
      W * 0.22,
      H * 0.18,
      W * 0.86
    );
    g.addColorStop(0, "rgba(34,211,238,.18)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    if (heatArr && heatArr.length === f.w * f.h) {
      const mn = Math.min(...heatArr),
        mx = Math.max(...heatArr);
      for (let y = 0; y < f.h; y++) {
        for (let x = 0; x < f.w; x++) {
          const v = heatArr[y * f.w + x];
          const t = (v - mn) / (mx - mn + 1e-9);
          ctx.fillStyle = `rgba(59,130,246,${0.03 + 0.22 * t})`;
          ctx.fillRect(pad + x * cellW, pad + y * cellH, cellW, cellH);
        }
      }
    }

    ctx.strokeStyle = "rgba(44,74,140,.75)";
    ctx.lineWidth = 1.4;
    for (let i = 0; i <= f.w; i++) {
      ctx.beginPath();
      ctx.moveTo(pad + i * cellW, pad);
      ctx.lineTo(pad + i * cellW, pad + f.h * cellH);
      ctx.stroke();
    }
    for (let j = 0; j <= f.h; j++) {
      ctx.beginPath();
      ctx.moveTo(pad, pad + j * cellH);
      ctx.lineTo(pad + f.w * cellW, pad + j * cellH);
      ctx.stroke();
    }

    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    const size = Math.min(cellW, cellH) * 0.72;
    ctx.font = `${size}px system-ui`;

    const drawOutlinedEmoji = (emoji, x, y) => {
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(0,0,0,0.85)";
      ctx.strokeText(emoji, x, y);
      ctx.lineWidth = 2;
      ctx.strokeStyle = "rgba(255,255,255,0.75)";
      ctx.strokeText(emoji, x, y);
      ctx.fillStyle = "#ffffff";
      ctx.fillText(emoji, x, y);
    };

    for (let y = 0; y < f.h; y++) {
      for (let x = 0; x < f.w; x++) {
        const ch = f.map[y][x];
        const cx = pad + (x + 0.5) * cellW;
        const cy = pad + (y + 0.5) * cellH;

        if (ch === "H") {
          ctx.fillStyle = "rgba(255,70,70,0.18)";
          ctx.fillRect(
            pad + x * cellW + 2,
            pad + y * cellH + 2,
            cellW - 4,
            cellH - 4
          );
          ctx.strokeStyle = "rgba(255,70,70,0.42)";
          ctx.lineWidth = 2;
          ctx.strokeRect(
            pad + x * cellW + 2,
            pad + y * cellH + 2,
            cellW - 4,
            cellH - 4
          );
          drawOutlinedEmoji("🧊", cx, cy);
        } else if (ch === "G") {
          ctx.fillStyle = "rgba(34,211,238,0.10)";
          ctx.fillRect(
            pad + x * cellW + 2,
            pad + y * cellH + 2,
            cellW - 4,
            cellH - 4
          );
          drawOutlinedEmoji("🏁", cx, cy);
        }
      }
    }

    const ax = f.agent[0],
      ay = f.agent[1];
    drawOutlinedEmoji("☃️", pad + (ax + 0.5) * cellW, pad + (ay + 0.5) * cellH);

    if (policy && policy.length === f.w * f.h) {
      ctx.strokeStyle = "rgba(34,211,238,.55)";
      ctx.lineWidth = 1.2;
      for (const p of policy) {
        const x = p[0],
          y = p[1],
          a = p[2];
        const cx = pad + (x + 0.5) * cellW;
        const cy = pad + (y + 0.5) * cellH;
        const len = Math.min(cellW, cellH) * 0.16;
        let dx = 0,
          dy = 0;
        if (a === 0) dy = -1;
        if (a === 1) dx = 1;
        if (a === 2) dy = 1;
        if (a === 3) dx = -1;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + dx * len, cy + dy * len);
        ctx.stroke();
      }
    }
  };

  const drawCartPole = (ctx, f) => {
    const W = main.width,
      H = main.height;
    ctx.clearRect(0, 0, W, H);

    const g = ctx.createRadialGradient(
      W * 0.36,
      H * 0.24,
      18,
      W * 0.36,
      H * 0.24,
      W * 0.95
    );
    g.addColorStop(0, "rgba(59,130,246,.18)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    const baseY = H * 0.72;
    ctx.fillStyle = "rgba(44,74,140,.28)";
    roundRect(ctx, 60, baseY, W - 120, 12, 8);
    ctx.fill();

    const x = (f.x / 2.4) * (W * 0.32) + W * 0.5;
    const cartW = 76,
      cartH = 28;
    const cartX = x - cartW / 2;
    const cartY = baseY - cartH;

    ctx.fillStyle = "rgba(34,211,238,.14)";
    ctx.strokeStyle = "rgba(34,211,238,.42)";
    ctx.lineWidth = 2;
    roundRect(ctx, cartX, cartY, cartW, cartH, 12);
    ctx.fill();
    ctx.stroke();

    const poleLen = 120;
    const th = f.theta;
    const x0 = x;
    const y0 = cartY;
    const x1 = x0 + Math.sin(th) * poleLen;
    const y1 = y0 - Math.cos(th) * poleLen;

    ctx.strokeStyle = "rgba(96,165,250,.90)";
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1, y1);
    ctx.stroke();

    ctx.fillStyle = "rgba(96,165,250,.95)";
    ctx.beginPath();
    ctx.arc(x1, y1, 10, 0, Math.PI * 2);
    ctx.fill();

    ctx.font = "42px system-ui";
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
  };

  const drawMountain = (ctx, f) => {
    const W = main.width,
      H = main.height;
    ctx.clearRect(0, 0, W, H);

    const lg = ctx.createLinearGradient(0, 0, W, H);
    lg.addColorStop(0, "rgba(59,130,246,.12)");
    lg.addColorStop(1, "rgba(34,211,238,.08)");
    ctx.fillStyle = lg;
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = "rgba(44,74,140,.75)";
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    for (let i = 0; i <= W; i++) {
      const x = i / W;
      const y = Math.sin(3 * (x * 1.8 - 1.2)) * 0.26;
      const py = H * 0.62 - y * H * 0.55;
      if (i === 0) ctx.moveTo(i, py);
      else ctx.lineTo(i, py);
    }
    ctx.stroke();

    const pos = f.pos;
    const xNorm = (pos + 1.2) / 1.8;
    const cx = xNorm * (W - 120) + 60;
    const hillY = yAt(cx);

    ctx.font = "54px system-ui";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("🚌", cx, hillY - 28);

    const gx = ((0.5 + 1.2) / 1.8) * (W - 120) + 60;
    const gy = yAt(gx);
    ctx.font = "36px system-ui";
    ctx.fillText("🏁", gx + 18, gy - 44);

    function yAt(px) {
      const x = px / W;
      const y = Math.sin(3 * (x * 1.8 - 1.2)) * 0.26;
      return H * 0.62 - y * H * 0.55;
    }
  };

  const drawBreakoutClean = (ctx, f) => {
    const Wc = ctx.canvas.width,
      Hc = ctx.canvas.height;

    ctx.clearRect(0, 0, Wc, Hc);
    const bg = ctx.createLinearGradient(0, 0, 0, Hc);
    bg.addColorStop(0, "rgba(6,14,36,0.95)");
    bg.addColorStop(1, "rgba(4,10,26,0.98)");
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, Wc, Hc);

    const pad = Math.floor(Math.min(Wc, Hc) * 0.07);
    const x0 = pad,
      y0 = pad;
    const w0 = Wc - 2 * pad,
      h0 = Hc - 2 * pad;

    const asp = f.W / f.H;
    const targetH = Math.floor(Hc * 0.7);

    let h = Math.min(h0, targetH);
    let w = Math.floor(h * asp);
    if (w > w0) {
      w = w0;
      h = Math.floor(w0 / asp);
    }

    const ox = x0 + Math.floor((w0 - w) / 2);
    const oy = y0 + Math.floor((h0 - h) / 2);

    const sx = w / f.W;
    const sy = h / f.H;

    const brickShiftY = Math.floor(h * 0.22);

    ctx.fillStyle = "rgba(96,165,250,0.6)";
    for (const b of f.bricks || []) {
      let bx = ox + b[0] * sx,
        by = oy + b[1] * sy + brickShiftY,
        bw = b[2] * sx,
        bh = b[3] * sy;
      bx = Math.max(ox + 2, Math.min(bx, ox + w - 4));
      by = Math.max(oy + 2, Math.min(by, oy + h - 4));
      bw = Math.max(1, Math.min(bw, ox + w - bx - 2));
      bh = Math.max(1, Math.min(bh, oy + h - by - 2));
      roundRect(ctx, bx, by, bw, bh, Math.max(6, Math.floor(bh * 0.35)));
      ctx.fill();
    }

    const p = f.paddle;
    let pw = p[2] * sx,
      ph = p[3] * sy;
    let px = ox + (p[0] - p[2] / 2) * sx,
      py = oy + p[1] * sy + brickShiftY;
    px = Math.max(ox + 2, Math.min(px, ox + w - pw - 2));
    py = Math.max(oy + 2, Math.min(py, oy + h - ph - 2));
    ctx.fillStyle = "rgba(34,211,238,0.75)";
    roundRect(ctx, px, py, pw, ph, Math.max(7, Math.floor(ph * 0.6)));
    ctx.fill();

    const ball = f.ball;
    const bx = ox + ball[0] * sx;
    const by = oy + ball[1] * sy + brickShiftY;
    const br = Math.max(6, ball[2] * sx);
    ctx.beginPath();
    ctx.fillStyle = "rgba(236,243,255,0.95)";
    ctx.arc(bx, by, br, 0, Math.PI * 2);
    ctx.fill();
  };

  const drawGym4Real = (ctx, env) => {
    const W = ctx.canvas.width;
    const H = ctx.canvas.height;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = "rgba(255,255,255,.08)";
    ctx.fillRect(30, 50, W - 60, H - 100);
    const e = env.energy / env.energy_max;
    const p = env.progress / env.goal;
    ctx.fillStyle = "rgba(124,92,255,.55)";
    ctx.fillRect(50, 90, (W - 100) * e, 36);
    ctx.fillStyle = "rgba(32,201,151,.55)";
    ctx.fillRect(50, 160, (W - 100) * p, 36);
    ctx.fillStyle = "rgba(255,255,255,.75)";
    ctx.font = "14px ui-sans-serif";
    ctx.fillText(`Energy: ${env.energy}/${env.energy_max}`, 50, 82);
    ctx.fillText(`Progress: ${env.progress}/${env.goal}`, 50, 152);
    ctx.fillStyle = "rgba(255,255,255,.45)";
    ctx.fillText("Actions: Rest / Work / Focus", 50, 230);
  };

  ws.onopen = () => {
    statusText.textContent = "Connected";
    showToast("Connected");
  };

  ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data || "{}");
    if (msg.type === "spec") {
      spec = msg;
      rebuildSelects();
    }
    if (msg.type === "cfg") {
      applyCfg(msg.cfg || {});
      anim.queue.length = 0;
      anim.playing = false;
      anim.lastAgent = null;
    }
    if (msg.type === "tick") {
      const m = msg.metrics || {};
      metrics.textContent = JSON.stringify(m, null, 2);

      const viz = msg.viz || {};
      const f = viz.frame || {};
      const policy = viz.policy || [];
      const heatArr = viz.V || viz.Qmax || [];

      if (typeof m.return === "number") returns.push(m.return);
      else if (typeof m.score === "number") returns.push(m.score);
      if (returns.length > 600) returns = returns.slice(-600);

      if (f.kind === "grid" || f.kind === "lake") {
        enqueueGridSteps(f, policy, heatArr);
        return;
      }

      document.body.classList.toggle("bigMode", f.kind === "breakout");
      fitCanvas();
      const ctx = main.getContext("2d");
      if (f.kind === "cartpole") drawCartPole(ctx, f);
      else if (f.kind === "mountaincar") drawMountain(ctx, f);
      else if (f.kind === "breakout") drawBreakoutClean(ctx, f);
      else if (f.kind === "gym4real") drawGym4Real(ctx, f);
      else ctx.clearRect(0, 0, main.width, main.height);

      drawHeat(heatArr);
      drawPlot(returns);
    }

    if (msg.type === "traj") {
      const t = msg.traj || {};
      if (t.error) return showToast(t.error);
      showToast(
        `Inference: return=${(t.return ?? 0).toFixed(2)} | steps=${t.steps}`
      );
    }
  };

  ws.onclose = () => {
    statusText.textContent = "Disconnected";
    showToast("Disconnected");
  };
})();